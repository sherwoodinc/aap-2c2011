package budapest.pest.ast.params;

public abstract class ConcreteParam {

}
