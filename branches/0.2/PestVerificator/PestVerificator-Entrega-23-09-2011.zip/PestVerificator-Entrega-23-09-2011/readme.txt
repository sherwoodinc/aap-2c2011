TRABAJO PRÁCTICO 1 - VERIFICACIÓN DE PROGRAMAS

Requisitos:

* CVC3 instalado y en el PATH
* Eclipse con el JDK

Importar el proyecto a un workspace. Correrlo.
El programa procesa cada argumento como un archivo fuente pest a procesar.

La carpeta de trabajo tiene la subcarpeta tests/ con los tests dados por la 
cátedra, sus versiones corregidas  donde fuera pertinente, y otros tests que
nos pareció interesante incluir.

De esta manera, editando los argumentos de ejecución se puede correr los tests 
que se quiera ver.

Cada archivo pest genera un archivo de salida .cvc3, y además otro archivo con
el resultado de procesar el .cvc3 con el CVC3 a continuación de los comandos 
CVC ejecutados.