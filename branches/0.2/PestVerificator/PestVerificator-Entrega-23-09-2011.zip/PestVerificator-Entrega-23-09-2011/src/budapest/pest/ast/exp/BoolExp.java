package budapest.pest.ast.exp;

public abstract class BoolExp extends Exp {

	public BoolExp(int line, int column) {
		super(line, column);
	}

}
