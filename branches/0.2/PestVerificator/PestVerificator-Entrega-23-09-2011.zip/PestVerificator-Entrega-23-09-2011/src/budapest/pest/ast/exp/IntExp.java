package budapest.pest.ast.exp;

public abstract class IntExp extends Exp {

	public IntExp(int line, int column) {
		super(line, column);
	}
	
}
