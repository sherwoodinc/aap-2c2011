package budapest.pest.ast;

public enum Type {
	INT
}
