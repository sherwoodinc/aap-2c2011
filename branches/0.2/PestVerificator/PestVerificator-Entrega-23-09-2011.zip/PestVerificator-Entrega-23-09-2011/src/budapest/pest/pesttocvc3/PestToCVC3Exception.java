package budapest.pest.pesttocvc3;

public class PestToCVC3Exception extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public PestToCVC3Exception(){}
	public PestToCVC3Exception(String message){
		super(message);
	}
}
