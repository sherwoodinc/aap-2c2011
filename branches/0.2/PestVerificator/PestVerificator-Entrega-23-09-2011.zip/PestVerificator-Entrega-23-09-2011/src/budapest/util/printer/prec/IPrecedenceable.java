package budapest.util.printer.prec;

public interface IPrecedenceable {

	public Precedence getPrecedence();
	
}
